const produtos = document.getElementById("produtos")

import BD from "../BancoDeDados.json"

console.log(BD)