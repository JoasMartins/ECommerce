# Trabalho de website - ADS

## Links
- Página 1: Início - Produtos a venda, links gerais.
- Página 2: Modelo:
- Página 3: Carrinho - Finalizar compra de produtos selecionados pelo usuário.
- Página 4: Vender produto - Adicionar produtos a venda no catálogo.
